import{_ as m}from"./burndown.vue_vue_type_script_setup_true_lang-DOSpqIDg.js";import"./index-DEzKSmHN.js";export{m as default};
