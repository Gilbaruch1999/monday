import{_ as m}from"./burndown.vue_vue_type_script_setup_true_lang-CdpnrMMJ.js";import"./index-DAD2GlgY.js";export{m as default};
